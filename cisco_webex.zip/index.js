const ciscospark = require(`ciscospark`);

var express = require('express');
const bodyParser = require('body-parser');
var http = require('http');
var path = require('path');
var cors = require('cors');
var app = express();
var Request = require("request");
var jwt = require('jsonwebtoken');

// Set up the path for the quickstart.
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
const multer = require('multer')()
var frontEnd = path.join(__dirname, './views');
console.log(frontEnd, 'frontEnd');
app.use('/views', express.static(frontEnd));
app.use('/*.js', express.static(frontEnd));
var ciscoObject;
var spark;
var guestValue;
var imei;
var actualToken;
var cisco_accessToken;

// app.use(function(req, res, next) {
//      spark = ciscospark.init({
//         config: {
//             phone: {
//               enableExperimentalGroupCallingSupport: true
//             }
//           },
//           credentials: {
//             access_token: "Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0"
//           }
//     });

//      spark.once(`ready`, next);
//   });
app.get('/file', function (req, response) {
    // response.send('hello worlds');
    imei = req.query.imei;
    response.render('widget')
});

app.get('/', function (req, res) {
    // res.sendFile(frontEnd + '/index.html');
    // return a new array with value [2, 4]
    // guestValue = req.query.name;
    var id = req.query.id;
    console.log(req.query.id);




    let data3 = 'C96d389d632c96d038d8f404c35904b5108988bd6d601d4b47f4eec88a569d5db';
    let buff1 = new Buffer(data3, 'base64');
    let text = buff1.toString('ascii');


    console.log('"' + data3 + '" converted from Base64 to ASCII is "' + text + '"');

    let data2 = text;
    let buff = new Buffer.from(data2);
    let base64data = buff.toString('base64');

    console.log('"' + data2 + '" converted to Base64 is "' + base64data + '"');

    var data = [{
        "id": 1234, "fname": "Enter your first name?", "lname": "Enter your first name?", "mobile": "Enter your mobile",
        "email": "Enter your valid email", "addressline1": "Enter Address line 1", "addressline2": "Enter Address Line2",
        "zipcode": "Enter your zipcode", "country": "Enter your country name", "medical_plan_question": 'Choose below plans',
        "medical_plan_type": "free", "medical_plans": ['General', 'Ortho']
    },
    {
        id: 1235, fname: "Enter your first name?", lname: "Enter your first name?", mobile: "Enter your mobile",
        email: "Enter your valid email", addressline1: "Enter Address line 1", addressline2: "Enter Address Line2",
        zipcode: "Enter your zipcode", country: "Enter your country name", medical_plan_question: 'Choose below plans',
        medical_plan_type: "premium", medical_plans: ['General', 'Ortho', 'Dental', 'Gastro', 'Heart']
    }, {
        id: 1236,
        fname: "Enter your first name?", lname: "Enter your first name?", mobile: "Enter your mobile",
        email: "Enter your valid email", addressline1: "Enter Address line 1", addressline2: "Enter Address Line2",
        zipcode: "Enter your zipcode", country: "Enter your country name", medical_plan_question: 'Choose below plans',
        medical_plan_type: "both", medical_plans: ['General', 'Ortho', 'Dental', 'Gastro']
    }];
    var filterOne = data.filter(items => items.id == id);
    if (filterOne) {
        res.send({ success: true, data: text, data1: base64data })
    } else {
        res.send({ success: false, data: [] })
    }

});

app.get('/guestUserToken', function (req, res) {
    guestValue = req.query.name;
    console.log(guestValue);
    var spark = ciscospark.init();
    var HEADER = {
        "alg": "HS256",
        "typ": "JWT"
    };
    var PAYLOAD = {
        "sub": "test",
        "name": guestValue,
        "iss": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi8zMzFiNTNmYS01ZGNmLTQwYjUtYTMyMy0zYjVmZjEyMTM0NGY"
    }

    var secret = `bj4uJQ5iCsEfDOxVIibHlJXoAZkIt9UgwhZHeE5wsPA=`;
    var test = new Buffer.from(secret, 'base64')
    var token = jwt.sign(
        PAYLOAD,
        test
    );
    actualToken = token;
    console.log(token, 'real token');
    if (token) {
        res.send({
            success: true,
            jwtToken: token
        })
    } else {
        res.send({
            success: false,
            jwtToken: null
        })
    }

    // var token = 'your.guest.token.here';bj4uJQ5iCsEfDOxVIibHlJXoAZkIt9UgwhZHeE5wsPA=
    // wait until the SDK is loaded and ready
    // spark.once(`ready`, function () {
    //     spark.authorization.requestAccessTokenFromJwt({ jwt: token })
    //         .then((testToken) => {

    //             console.log(testToken, 'testToken');

    //             // if (token) {
    //             // Request.post({
    //             //     "headers": { "Authorization":`Bearer ${token}` },
    //             //     "url": "https://api.ciscospark.com/v1/messages",
    //             //     "body":JSON.stringify({roomId:"Y2lzY29zcGFyazovL3VzL1JPT00vYmNkNTcyMzAtNWI3Zi0xMWU5LWE3YTItYTlhYzYwZTY2MDMy",text: "This is message sent  by guest user" })
    //             //     }, (error, res, body) => {
    //             //         console.log(res , 'res server');
    //             //         if (error) {
    //             //             return false;
    //             //         } else {
    //             //             let data = JSON.parse(res.body);
    //             //             // if(data.Valid){
    //             //             return res.send({ notes: data, date: new Date(), status: true });
    //             //             // } else {
    //             //             //   return response.send({notes:'no active records found in userDevice for this imei', date:new Date(), status:false});
    //             //             // }

    //             //         }
    //             //     });
    //             // } else {
    //             //     res.send({ tok: 'Token not created' })
    //             // }
    //         })
    // });
});


app.get('/addNotes', function (req, res) {
    console.log(req.query.Notes, 'addNotes');
    console.log(imei, 'addNotes');
    Request.post({
        "headers": { "content-type": "application/json" },
        "url": "http://devapi.tracktechllc.com/tracktech/api/devicedata/UpdateNotes",
        "body": JSON.stringify({ Notes: req.query.Notes, imei: imei })
    }, (error, response, body) => {
        console.log(body);
        if (error) {
            return false;
        } else {
            return res.send(true);
        }
    });
});
app.get('/getNotes', function (req, res) {
    console.log(req.query.Notes, 'GetNotes');
    console.log(imei, 'GetNotes');

    Request.get({
        "headers": { "content-type": "application/json" },
        "url": "http://devapi.tracktechllc.com/tracktech/api/devicedata/GetAllVTCNotes?imei=" + imei,
    }, (error, response, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let data = JSON.parse(response.body);
            if (data.Valid) {
                let prev_notes = []
                data.Items.forEach(item => {
                    prev_notes.push({ notes: item.Notes, date: item.DateTimeStamp })
                });
                return res.send({ notes: prev_notes, date: new Date(), status: true });
            } else {
                return res.send({ notes: 'no active records found in userDevice for this imei', date: new Date(), status: false });
            }

        }
    });
});


app.get('/getGoogleFormsData', function (req, res) {
    console.log(req.query.p_id, 'GetNotes');
    console.log(imei, 'GetNotes');
    var data = [{
        id: 1234,
        fname: "Enter your first name?",
        lname: "Enter your first name?",
        mobile: "Enter your mobile",
        email: "Enter your valid email",
        addressline1: "Enter Address line 1",
        addressline2: "Enter Address Line2",
        zipcode: "Enter your zipcode",
        country: "Enter your country name",
        medical_plan_question: 'Choose below plans',
        medical_plan_type: "free",
        medical_plans: ['General', 'Ortho']
    },
    {
        id: 1235,
        fname: "Enter your first name?",
        lname: "Enter your first name?",
        mobile: "Enter your mobile",
        email: "Enter your valid email",
        addressline1: "Enter Address line 1",
        addressline2: "Enter Address Line2",
        zipcode: "Enter your zipcode",
        country: "Enter your country name",
        medical_plan_question: 'Choose below plans',
        medical_plan_type: "premium",
        medical_plans: ['General', 'Ortho', 'Dental', 'Gastro', 'Heart']
    }, {
        id: 1236,
        fname: "Enter your first name?",
        lname: "Enter your first name?",
        mobile: "Enter your mobile",
        email: "Enter your valid email",
        addressline1: "Enter Address line 1",
        addressline2: "Enter Address Line2",
        zipcode: "Enter your zipcode",
        country: "Enter your country name",
        medical_plan_question: 'Choose below plans',
        medical_plan_type: "both",
        medical_plans: ['General', 'Ortho', 'Dental', 'Gastro']
    }];
    Request.get({
        "headers": { "content-type": "application/json" },
        "url": "http://devapi.tracktechllc.com/tracktech/api/devicedata/GetAllVTCNotes?imei=" + imei,
    }, (error, response, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let data = JSON.parse(response.body);
            if (data.Valid) {
                let prev_notes = []
                data.Items.forEach(item => {
                    prev_notes.push({ notes: item.Notes, date: item.DateTimeStamp })
                });
                return res.send({ notes: prev_notes, date: new Date(), status: true });
            } else {
                return res.send({ notes: 'no active records found in userDevice for this imei', date: new Date(), status: false });
            }

        }
    });
});


app.get('/token_Access', function (req, res) {
    ciscoObject = ciscospark.init({
        credentials: {
            access_token: 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0'
        }
    });
    console.log(ciscoObject, 'ciscoObject');

    if (ciscoObject) {
        res.send({
            status: true,
            event: ciscoObject.sessionId,
            result: 'Connected'
        });
    } else {
        res.send({
            status: false,
            event: 'Button click works',
            result: 'Disconnected'
        });
    }
});


app.get('/createTeam', function (req, res) {
    ciscoObject.teams.create({ name: 'someteam' }).then(team => {
        console.log(team, 'is created team');
        return res.send({
            status: true,
            message: 'Team Created'
        })
    }).catch((err) => {
        if (err) {
            res.send({
                status: false,
                message: err
            })
        }
    })
})
// // iscospark.teams.list({max: 3});
// app.get('/getTeams', function (req, res) {
//     ciscoObject.teams.list({ max: 10 }).then(function (teams) {
//         console.log(teams, 'list of teams');
//         res.send({
//             status: true,
//             message: 'list of teams',
//             data: teams
//         })
//     }).catch((err) => {
//         if (err) {
//             res.send({
//                 status: false,
//                 message: err,
//                 data: []
//             })
//         }
//     });
// })


app.get('/getTeams1', function (request, response) {
    Request.get({
        "headers": { "Authorization": 'Bearer ODEzMDAzYzgtMjM5Yi00OTI5LWEwNmYtOTIyMDc1NjFmODYwNTI5NzU0MmQtMWMx_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
        "url": "https://api.ciscospark.com/v1/teams"
        // "body": JSON.stringify({Notes:request.query.Notes,imei:userRoom})
    }, (error, res, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let data = JSON.parse(res.body);
            // if(data.Valid){
            return response.render('index', { data: data, date: new Date(), status: true })
            //  response.send({ notes: data, date: new Date(), status: true });
            // } else {
            //   return response.send({notes:'no active records found in userDevice for this imei', date:new Date(), status:false});
            // }

        }
    });
});

app.get('/createTeam', async function (request, response) {
    // var response = await ciscoWeb_ApiCall('https://api.ciscospark.com/v1/teams', 'POST', { name: 'TEST_TEAM3' })
    Request.post({
        "headers": { "Content-type": "Application/json", "Authorization": 'Bearer ODEzMDAzYzgtMjM5Yi00OTI5LWEwNmYtOTIyMDc1NjFmODYwNTI5NzU0MmQtMWMx_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
        "url": "https://api.ciscospark.com/v1/teams",
        "body": JSON.stringify({ name: 'TEST_TEAM3' })
    }, (error, res, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let data = JSON.parse(res.body);
            // if(data.Valid){

            return response.send({ notes: data, date: new Date(), status: true });
            // } else {
            //   return response.send({notes:'no active records found in userDevice for this imei', date:new Date(), status:false});
            // }

        }
    });
});

app.get('/getTeams', async function (request, response) {
    // var response = await ciscoWeb_ApiCall('https://api.ciscospark.com/v1/teams', 'POST', { name: 'TEST_TEAM3' })
    Request.get({
        "headers": { "Content-type": "Application/json", "Authorization": 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
        "url": "https://api.ciscospark.com/v1/teams"
    }, (error, res, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let team = JSON.parse(res.body);
            // response.render('index', { data: data.items, date: new Date(), status: true })
            Request.get({
                "headers": { "Content-type": "Application/json", "Authorization": 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
                "url": "https://api.ciscospark.com/v1/team/memberships?teamId=Y2lzY29zcGFyazovL3VzL1RFQU0vNWE2ZjBiNDAtNWY1MC0xMWU5LTlhYzMtMzNmOGJmMGJhOGVm",
            }, (error, res, body) => {
                console.log(res.body, 'res server');
                if (error) {
                    return false;
                } else {
                    let team_members = JSON.parse(res.body);
                    Request.get({
                        "headers": { "Content-type": "Application/json", "Authorization": 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
                        "url": "https://api.ciscospark.com/v1/rooms?teamId=Y2lzY29zcGFyazovL3VzL1RFQU0vNWE2ZjBiNDAtNWY1MC0xMWU5LTlhYzMtMzNmOGJmMGJhOGVm"
                    }, (error, res, body) => {
                        console.log(res.body, 'res server');
                        if (error) {
                            return false;
                        } else {
                            let room = JSON.parse(res.body);
                            // if(data.Valid){
                            return response.render('index', {
                                team: team.items,
                                team_members: team_members.items,
                                room: room.items,
                                date: new Date(),
                                status: true
                            })
                            // return response.send({
                            //      team: team.items,
                            //      team_members:team_members.items,
                            //      room :room.items,
                            //      date: new Date(),
                            //       status: true });
                        }
                    });

                }
            });
            // return response.send({ notes: data, date: new Date(), status: true });
            // } else {
            //   return response.send({notes:'no active records found in userDevice for this imei', date:new Date(), status:false});
            // }

        }
    });
});

app.get('/getDetailsBySelection', async function (request, response) {
    // var response = await ciscoWeb_ApiCall('https://api.ciscospark.com/v1/teams', 'POST', { name: 'TEST_TEAM3' })
    console.log(request.query);

    let jsid = request.query.id;
    var team_members;
    var room;
    await Request.get({
        "headers": { "Content-type": "Application/json", "Authorization": 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
        "url": "https://api.ciscospark.com/v1/teams"
    }, async (error, res, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let team = JSON.parse(res.body);
            let teamId;
            // response.render('index', { data: data.items, date: new Date(), status: true })
            if (team.items) {
                teamId = team.items.filter(item => item.id == jsid);
                var url = "https://api.ciscospark.com/v1/team/memberships?teamId=" + teamId;
                var userDetails;
                var retData = initialize(url);

                retData.then(function (result) {
                    userDetails = result;
                    if (userDetails.errors.length > 0) {
                        team_members = [];

                        return response.render('index', {
                            team: (team.items) ? team.items : [],
                            team_members: [],
                            room: [],
                            date: new Date(),
                            status: true
                        })
                    }
                    console.log("Initialized user details");
                    // Use user details from here
                    console.log(userDetails)

                }, function (err) {
                    console.log(err);
                })

            }

        }
    });
});
function initialize(url) {
    // Setting URL and headers for request
    var options = {
        "headers": { "Content-type": "Application/json", "Authorization": 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
        "url": url
    };
    // Return new promise 
    return new Promise(function (resolve, reject) {
        // Do async job
        Request.get(options, function (err, resp, body) {
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(body));
            }
        })
    })

}

function main(url) {
    var initializePromise = initialize(url);
    initializePromise.then(function (result) {
        userDetails = result;

        console.log("Initialized user details");
        // Use user details from here
        console.log(userDetails)
        return userDetails;
    }, function (err) {
        console.log(err);
    })
}
app.get('/getTeamMemberships', async function (request, response) {
    // var response = await ciscoWeb_ApiCall('https://api.ciscospark.com/v1/teams', 'POST', { name: 'TEST_TEAM3' })
    console.log(request.query, 'query');

    Request.get({
        "headers": { "Content-type": "Application/json", "Authorization": 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
        "url": "https://api.ciscospark.com/v1/team/memberships?teamId=Y2lzY29zcGFyazovL3VzL1RFQU0vNWE2ZjBiNDAtNWY1MC0xMWU5LTlhYzMtMzNmOGJmMGJhOGVm",
    }, (error, res, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let data = JSON.parse(res.body);
            // if(data.Valid){
            return response.send({ notes: data, date: new Date(), status: true });
            // } else {
            //   return response.send({notes:'no active records found in userDevice for this imei', date:new Date(), status:false});
            // }

        }
    });
});

app.get('/getRooms', async function (request, response) {
    // var response = await ciscoWeb_ApiCall('https://api.ciscospark.com/v1/teams', 'POST', { name: 'TEST_TEAM3' })
    Request.get({
        "headers": { "Content-type": "Application/json", "Authorization": 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
        "url": "https://api.ciscospark.com/v1/rooms",
        // "body": JSON.stringify({ name: 'TEST_TEAM3' })
    }, (error, res, body) => {
        console.log(res.body, 'res server');
        if (error) {
            return false;
        } else {
            let data = JSON.parse(res.body);
            // if(data.Valid){
            return response.send({ notes: data, date: new Date(), status: true });
            // } else {
            //   return response.send({notes:'no active records found in userDevice for this imei', date:new Date(), status:false});
            // }
        }
    });
});


function ciscoWeb_ApiCall(url, method, body) {
    switch (method) {
        case 'POST':
            Request.post({
                "headers": { "Authorization": 'Bearer ODEzMDAzYzgtMjM5Yi00OTI5LWEwNmYtOTIyMDc1NjFmODYwNTI5NzU0MmQtMWMx_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
                "url": url,
                "body": JSON.stringify(body)
            }, (error, res, body) => {
                console.log(res.body, 'res server');
                if (error) {
                    return false;
                } else {
                    let data = JSON.parse(res.body);
                    return data;
                }
            });
            break;
        case 'GET':
            Request.get({
                "headers": { "Authorization": 'Bearer ODEzMDAzYzgtMjM5Yi00OTI5LWEwNmYtOTIyMDc1NjFmODYwNTI5NzU0MmQtMWMx_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0' },
                "url": url
            }, (error, res, body) => {
                console.log(res.body, 'res server');
                if (error) {
                    return false;
                } else {
                    let data = JSON.parse(res.body);
                    return data;
                }
            });
            break;
        default:
            break;
    }
}

app.get('/testCall', function (req, res) {
    // ciscoObject = ciscospark.init({
    //     credentials: {
    //         access_token: 'Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0'
    //     }
    // });
    // console.log(ciscoObject, 'ciscoObject');
    connect();
    if (ciscoObject) {
        res.send({
            status: true,
            event: ciscoObject.sessionId,
            result: 'Connected'
        });
    } else {
        res.send({
            status: false,
            event: 'Button click works',
            result: 'Disconnected'
        });
    }
});

app.post('/callback', function (req, res) {
    // res.send('hello worlds');
    console.log(req.body, 'from FITBIT');
    res.send({
        success: true,
        jwtToken: '12345'
    })
});

function connect() {
    console.log('Connect calling')
    if (!spark) {
        spark = ciscospark.init({
            config: {
                phone: {
                    enableExperimentalGroupCallingSupport: true
                }
            },
            credentials: {
                access_token: "Bearer MGE1ZjlhMmMtYTQ3YS00M2U0LTljYTktYTM4NTllYjhmZmRlMWY3MTg4MjItMGI1_PF84_a78a350f-a848-41dc-a9e1-f9e74c40d3c0"
            }
        });
        console.log('first if')
    }

    if (!spark.phone.registered) {
        console.log('second if')
        spark.phone.on('call:incoming', (call) => {
            Promise.resolve()
                .then(() => {
                    if (call.from && call.from.personId) {
                        console.log('second if inner', call)
                        return spark.people.get(call.from.personId);
                    }

                    return Promise.resolve();
                })
                .then((person) => {
                    const str = person ? `Anwser incoming call from ${person.displayName}` : 'Answer incoming call';

                    if (confirm(str)) {
                        call.answer();
                        bindCallEvents(call);
                    }
                    else {
                        call.decline();
                    }
                })
                .catch((err) => {
                    console.error(err);
                    alert(err);
                });
        });

        return spark.phone.register()
            .then(() => {
                // document.body.classList.add('listening');

                // document.getElementById('connection-status').innerHTML = 'connected';
            })
            .catch((err) => {
                console.error(err);
                alert(err.stack);
                throw err;
            });
    }

    return Promise.resolve();
}


app.get('/Dailer', async function (request, response) {
    Dailer()
});

function Dailer() {

    const call = spark.phone.dial('Y2lzY29zcGFyazovL3VzL1JPT00vOTZmODkwMjAtNWY1Mi0xMWU5LWIzNDYtZDNlNTA3OTcyNTE5');

    // Call our helper function for binding events to calls
    bindCallEvents(call);

}


function bindCallEvents(call) {
    console.log('bindCallEvents', call)
    call.on('error', (err) => {
        console.error(err);
        alert(err.stack);
    });
    call.once('localMediaStream:change', () => {
        // document.getElementById('self-view').srcObject = call.localMediaStream;
    });

    call.on('remoteMediaStream:change', () => {
        [
            'audio',
            'video'
        ].forEach((kind) => {
            if (call.remoteMediaStream) {
                const track = call.remoteMediaStream.getTracks().find((t) => t.kind === kind);

                if (track) {
                    //   document.getElementById(`remote-view-${kind}`).srcObject = new MediaStream([track]);
                }
            }
        });
    });

    // Once the call ends, we'll want to clean up our UI a bit
    call.on('inactive', () => {
        // Remove the streams from the UI elements
        // document.getElementById('self-view').srcObject = undefined;
        // document.getElementById('remote-view-audio').srcObject = undefined;
        // document.getElementById('remote-view-video').srcObject = undefined;
    });

    // Of course, we'd also like to be able to end the call:
    // document.getElementById('hangup').addEventListener('click', () => {
    //   call.hangup();
    // });
}


app.get('/createPerson', async function (req, response) {
    // var response = await ciscoWeb_ApiCall('https://api.ciscospark.com/v1/teams', 'POST', { name: 'TEST_TEAM3' })
    guestValue = req.query.name;
    console.log(guestValue);

    var spark = ciscospark.init();


    var HEADER = {
        "alg": "HS256",
        "typ": "JWT"
    };
    var PAYLOAD = {
        "sub": "test",
        "name": guestValue,
        "iss": "Y2lzY29zcGFyazovL3VzL09SR0FOSVpBVElPTi8zMzFiNTNmYS01ZGNmLTQwYjUtYTMyMy0zYjVmZjEyMTM0NGY"
    }

    var secret = `bj4uJQ5iCsEfDOxVIibHlJXoAZkIt9UgwhZHeE5wsPA=`;
    var test = new Buffer.from(secret, 'base64')
    var token = jwt.sign(
        PAYLOAD,
        test
    );
    actualToken = token;
    var token1 = actualToken;
    // wait until the SDK is loaded and ready
    spark.once(`ready`, function () {
        spark.authorization.requestAccessTokenFromJwt({ jwt: token1 })
            .then((res) => {
                console.log(res, 'res server');
                // the user is now authenticated with a guest token (JWT)
                // proceed with your app logic
                // Request.post({
                //     "headers": { "Content-type": "Application/json", "Authorization": `Bearer ${actualToken}` },
                //     "url": "https://api.ciscospark.com/v1/people",
                //     "body": JSON.stringify({ emails: 'rambabu90@yahoo.com',displayName:'RB',firstName:'ram',lastName:'emandi',avatar:null,orgId:null,roles:null,licenses:null })
                // }, (error, res, body) => {
                //     console.log(res.body, 'res server');
                //     if (error) {
                //         return false;
                //     } else {
                //         let data = JSON.parse(res.body);
                //         return response.send({ notes: data, date: new Date(), status: true });
                //     }
                // });
            })
    });

});

app.post('/activateUser', function (req, res) {
    // res.send('hello worlds');
    //https://web.ciscospark.com/activate?email=testinstitute%40yahoo.com&amp;vt=i&amp;t=BcFZEkMwAADQI6GWxqexS4hd%2BSOkaWuZsU04fd8zEt%2Fcddtz3C8bQCx%2Fiin%2FaajhtALDC9253WJs6XCxmFIXelx0sFZFqhGJDSR6gBUc7r2sAo9qFtRoH7Gg2spSar5Ls04O5ZFDrzWuJGXRiSFEVZt2IL88qUTYweI8KmYzT2EfHOTdcXJkifM0Od322dvyXtSS8%2F4D
    Request.post({
        "headers": {
            "authorization": "Basic Qzk2ZDM4OWQ2MzJjOTZkMDM4ZDhmNDA0YzM1OTA0YjUxMDg5ODhiZDZkNjAxZDRiNDdmNGVlYzg4YTU2OWQ1ZGI6YjExYzNlOTZhMGQ1MWY2NmZmOTY4NjIyMGI3NGUyYzBmNmM2Yzc2MzZiYmE5OGI3MWNhNWRiYmY1ZDY4OTZkNg==",
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": "https://teams.webex.com",
            // "Referer": "https://teams.webex.com/activate?email=testad4229%40yahoo.com&vt=i&t=BcHJEoIgAADQD%2BqQy5h6BHPBScAlrW6alrhMoFjq1%2FceiJEjbTfw%2FK5tLAK%2F22hHrM0L3GsyFAbqxOoj6VZHJUCKgK%2BU6JFx%2BNicki4b2JlHQ8yjMckNea%2BXw0OTVmAXIMWI6QhxeKqcGevTNO47pZZKwLzkXlmqHISspb16Eeai7%2BnNQD5gv2sjMzWrqy3DMImXna%2Fm%2B%2FkH",
            "Referer": "https://web.ciscospark.com/activate?email=testad4229%40yahoo.com&amp;vt=i&amp;t=BcFLEkMwAADQA3XhU9%2BlUBWVkBrUEiNMGERRcfq%2B5xDobvYj8J%2Bsby0cee2eYncPjF%2FprwLYdeHkAJ7yNVv0vtYrYiLPTM%2BWesqFeXWiCn74xJVMhJwMvOae8h516CkOeqUT8xum0m9g0rKmuz6kmg67MN7IrCZRsUjKomYWb5bbcX26IWf2NICYHDttQh21QDMwH1HzBw%3D%3D",
            "trackingid": "web-client_fe622da5-52f4-4197-b616-ac6e5468ca06_1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
        },
        "url": "https://idbroker.webex.com/idb/oauth2/v1/access_token",
        "body": "grant_type=client_credentials&scope=webexsquare%3Aadmin&self_contained_token=true"

    }, (error, resesponse, body) => {
        //  console.log(resesponse.body, 'cisco server access_token');
        if (error) {
            console.log(error, 'cisco error');
            return false;
        } else {
            let data = JSON.parse(resesponse.body);
            //   res.send({
            //     status: true,
            //     eventData: data,
            //     result: 'Connected'
            // });
            cisco_accessToken = data;
            console.log(cisco_accessToken, 'Cicso access token data');
            Request.post({
                "headers": {
                    "Accept": "application/json",
                    "authorization": "Bearer " + data.access_token,
                    "cisco-no-http-redirect": true,
                    "Content-Type": "application/json",
                    "Origin": "https://teams.webex.com",
                    // "Referer": "https://teams.webex.com/activate?email=testad4229%40yahoo.com&vt=i&t=BcHJEoIgAADQD%2BqQy5h6BHPBScAlrW6alrhMoFjq1%2FceiJEjbTfw%2FK5tLAK%2F22hHrM0L3GsyFAbqxOoj6VZHJUCKgK%2BU6JFx%2BNicki4b2JlHQ8yjMckNea%2BXw0OTVmAXIMWI6QhxeKqcGevTNO47pZZKwLzkXlmqHISspb16Eeai7%2BnNQD5gv2sjMzWrqy3DMImXna%2Fm%2B%2FkH",
                    "Referer": "https://web.ciscospark.com/activate?email=testad4229%40yahoo.com&amp;vt=i&amp;t=BcFLEkMwAADQA3XhU9%2BlUBWVkBrUEiNMGERRcfq%2B5xDobvYj8J%2Bsby0cee2eYncPjF%2FprwLYdeHkAJ7yNVv0vtYrYiLPTM%2BWesqFeXWiCn74xJVMhJwMvOae8h516CkOeqUT8xum0m9g0rKmuz6kmg67MN7IrCZRsUjKomYWb5bbcX26IWf2NICYHDttQh21QDMwH1HzBw%3D%3D",
                    "spark-user-agent": "webex-js-sdk/1.63.2 (web)",
                    "trackingid": "web-client_23b99d8b-0c75-48b5-b23c-3bbdd5d7cf30_2",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36",
                    "x-prelogin-userid": undefined
                },
                "url": "https://atlas-a.wbx2.com/admin/api/v1/users/activations",
                "body": JSON.stringify({ "reqId": "WEBCLIENT", "email": "testad4229@yahoo.com", "suppressEmail": true })
            }, (error, respon, body) => {
                console.log(respon, 'cisco server2 activations');
                if (error) {
                    console.log(error, 'CISCO error')
                    return false;
                } else {
                    let data1 = JSON.parse(respon.body);
                    Request.patch({
                        "headers": {
                            "Accept": application / json,
                            "authorization": "Bearer " + cisco_accessToken.access_token,
                            "cisco-device-url": "https://wdm-a.wbx2.com/wdm/api/v1/devices/21e4e2dd-5289-442e-a4ac-2d268ed000b9",
                            "cisco-no-http-redirect": true,
                            "Content-Type": "application/json",
                            "Origin": "https://teams.webex.com",
                            "Referer": "https://teams.webex.com/create-password",
                            "spark-user-agent": "webex-js-sdk/1.63.2 (web)",
                            "trackingid": "web-client_6f5a937b-d032-491b-b6c0-7214c7918839_15",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36"
                        },
                        "url": "https://identity.webex.com/identity/scim/v1/Users/"+data1.id,
                        "body": JSON.stringify({
                            "password": "Techno@12",
                            "schemas": ["urn:scim:schemas:core:1.0", "urn:scim:schemas:extension:cisco:commonidentity:1.0"]
                        })
                    }, (error, respons, body) => {
                        console.log(respons, 'cisco server2 passowrd');
                        if (error) {
                            console.log(error, 'CISCO error')
                            return false;
                        } else {
                            let data2 = JSON.parse(respons.body);
                            // Request.patch()
                            res.send({
                                status: true,
                                eventData: data2,
                                result: 'Connected'
                            });
                        }
                    });
                }
            });

        }
    });

});


var server = http.createServer(app);
var port = process.env.PORT || 3000;
server.listen(port, function () {
    var datetime = new Date();
    console.log(datetime.toISOString());
    console.log('Express server running on *:' + port);
});